
package ica7_generics;

public interface TwoDShape extends GeometricShape {
    public double area();
}
