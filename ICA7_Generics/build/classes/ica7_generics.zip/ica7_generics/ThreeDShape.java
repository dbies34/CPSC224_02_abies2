
package ica7_generics;

public interface ThreeDShape extends GeometricShape {
    public double volume();
}
