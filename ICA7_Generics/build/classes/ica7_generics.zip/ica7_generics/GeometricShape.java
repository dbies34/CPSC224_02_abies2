// interface for geometric shapes of all kinds

package ica7_generics;

public interface GeometricShape {
    public void describe();
}
